
<?php /**PATH /home/ahmad/Notes/Laravel/Test development/Inventory/Inventory-Module/inventory/resources/views/vendor/nova/partials/meta.blade.php ENDPATH**/ ?>